Ye poora Gradle project hai. GitHub Actions isse APK bana deta hai.
Steps chat mein bataye gaye hain.
