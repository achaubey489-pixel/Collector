package com.example.collector

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent

class ShotService : AccessibilityService() {
    companion object { @Volatile var instance: ShotService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            capture()
            handler.postDelayed(this, Engine.intervalMin * 60_000L)
        }
    }

    override fun onServiceConnected() {
        instance = this
        Engine.init(this)
        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 10_000)
    }

    fun captureIn(ms: Long) { handler.postDelayed({ capture() }, ms) }

    fun capture() {
        if (rootInActiveWindow?.packageName == packageName) {
            Engine.lastResult = "Apna app khula tha, screenshot skip"
            return
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bmp != null) Engine.process(bmp)
            }
            override fun onFailure(errorCode: Int) {
                Engine.lastResult = "Screenshot fail (code $errorCode)"
            }
        })
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}
