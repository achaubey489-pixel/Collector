package com.example.collector

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ShotService : AccessibilityService() {
    companion object { @Volatile var instance: ShotService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var overlay: Overlay
    private var lastEventRead = 0L
    private val loop = object : Runnable {
        override fun run() {
            capture()
            handler.postDelayed(this, Engine.intervalSec * 1000L)
        }
    }

    override fun onServiceConnected() {
        instance = this
        Engine.init(this)
        overlay = Overlay(this)
        Engine.onUpdate = { overlay.refresh() }
        if (Engine.overlayOn) overlay.show()
        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 5_000)
    }

    fun toggleOverlay() {
        if (overlay.isShown()) { overlay.hide(); Engine.overlayOn = false }
        else { Engine.overlayOn = true; overlay.show() }
    }

    fun captureIn(ms: Long) { handler.postDelayed({ capture() }, ms) }

    // ---------- screen ka text seedha padhna ----------
    private fun walk(n: AccessibilityNodeInfo?, depth: Int, out: MutableList<Engine.NodeText>) {
        if (n == null || depth > 60) return
        val t = (n.text ?: n.contentDescription)?.toString()
        if (!t.isNullOrBlank()) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.height() > 0) out.add(Engine.NodeText(t, r.centerX(), r.centerY(), r.height()))
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, out)
    }

    fun scanNodes(): List<Engine.NodeText>? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName == packageName) return null
        val out = ArrayList<Engine.NodeText>()
        walk(root, 0, out)
        return out
    }

    private fun readNodes(): Boolean {
        val nodes = scanNodes() ?: return false
        return Engine.processNodes(nodes)
    }

    fun textTestIn(ms: Long) {
        handler.postDelayed({
            val n = scanNodes()
            Engine.toolText = if (n == null) "Text test: koi active window nahi mili (game par the?)"
            else Engine.describeNodes(n)
        }, ms)
    }

    // ---------- har interval par: pehle text, na mile to screenshot ----------
    fun capture() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) {
            Engine.lastResult = "Screen band hai, skip"
            return
        }
        if (rootInActiveWindow?.packageName == packageName) {
            Engine.lastResult = "Apna app khula tha, skip"
            return
        }
        if (readNodes()) return

        overlay.setCapturing(true)
        handler.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    overlay.setCapturing(false)
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp != null) Engine.process(bmp)
                }
                override fun onFailure(errorCode: Int) {
                    overlay.setCapturing(false)
                    Engine.lastResult = "Screenshot fail (code $errorCode)"
                }
            })
        }, 250)
    }

    // TEXT mode chal raha ho to naya round aate hi turant padho
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || Engine.readVia != "TEXT") return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        if (event.packageName == packageName) return
        val now = System.currentTimeMillis()
        if (now - lastEventRead < 1500) return
        lastEventRead = now
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) return
        readNodes()
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(loop)
        Engine.onUpdate = null
        if (::overlay.isInitialized) overlay.hide()
        super.onDestroy()
    }
}
