package com.example.collector

import android.content.Context
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Engine {
    const val TARGET = 10000
    const val NEXT_N = 60

    private lateinit var ctx: Context
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    @Volatile var db: MutableList<Double> = mutableListOf()
    @Volatile var lastNumbers: List<Double> = emptyList()
    @Volatile var lastResult: String = "Abhi tak koi screenshot nahi"
    @Volatile var backtestText: String = ""

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        val f = File(ctx.filesDir, "db.txt")
        if (f.exists()) {
            db = f.readText().split(",").filter { it.isNotBlank() }.map { it.toDouble() }.toMutableList()
        }
    }

    private fun prefs() = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var topPct: Int
        get() = prefs().getInt("top", 0)
        set(v) { prefs().edit().putInt("top", v).apply() }
    var bottomPct: Int
        get() = prefs().getInt("bottom", 100)
        set(v) { prefs().edit().putInt("bottom", v).apply() }
    var intervalMin: Int
        get() = prefs().getInt("interval", 60)
        set(v) { prefs().edit().putInt("interval", v.coerceAtLeast(1)).apply() }
    var reverse: Boolean
        get() = prefs().getBoolean("reverse", false)
        set(v) { prefs().edit().putBoolean("reverse", v).apply() }

    private fun saveDb() = File(ctx.filesDir, "db.txt").writeText(db.joinToString(","))

    fun reset() {
        db = mutableListOf(); saveDb()
        lastResult = "Data reset ho gaya"; lastNumbers = emptyList(); backtestText = ""
    }

    fun mode() = if (db.size < TARGET) "COLLECT" else "MATCH"

    // ---- screenshot -> OCR ----
    fun process(bmp: Bitmap) {
        val h = bmp.height
        val t = (h * topPct / 100).coerceIn(0, h - 2)
        val b = (h * bottomPct / 100).coerceIn(t + 1, h)
        val crop = Bitmap.createBitmap(bmp, 0, t, bmp.width, b - t)
        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { handle(it.text) }
            .addOnFailureListener { lastResult = "OCR error: ${it.message}" }
    }

    @Synchronized
    private fun handle(text: String) {
        var nums = Regex("""\d+\.\d+""").findAll(text).map { it.value.toDouble() }.toList()
        if (reverse) nums = nums.reversed()
        lastNumbers = nums
        val stamp = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
        if (nums.isEmpty()) { lastResult = "[$stamp] Koi number nahi mila"; return }

        if (db.size < TARGET) {
            db = merge(db, nums).toMutableList()
            saveDb()
            lastResult = "[$stamp] Collect: ${db.size}/$TARGET"
        } else {
            val m = findNext(db, nums)
            lastResult = if (m.isEmpty()) "[$stamp] Match nahi mila"
            else "[$stamp] ${m.size} match mile\n" +
                m.take(3).joinToString("\n") { "pos ${it.first}: ${it.second}" }
            File(ctx.filesDir, "predictions.txt").appendText(lastResult + "\n")
        }
    }

    // ---- logic ----
    fun merge(db: List<Double>, new: List<Double>): List<Double> {
        for (k in minOf(db.size, new.size) downTo 1) {
            if (db.subList(db.size - k, db.size) == new.subList(0, k)) return db + new.subList(k, new.size)
        }
        return db + new
    }

    fun findNext(db: List<Double>, seq: List<Double>): List<Pair<Int, List<Double>>> {
        val out = mutableListOf<Pair<Int, List<Double>>>()
        val l = seq.size
        if (l == 0) return out
        for (i in 0..(db.size - l - 1)) {
            if (db[i] != seq[0]) continue
            var ok = true
            for (j in 1 until l) if (db[i + j] != seq[j]) { ok = false; break }
            if (ok) out.add(i to db.subList(i + l, minOf(i + l + NEXT_N, db.size)).toList())
        }
        return out
    }

    // 70% data se seekho, baaki 30% par test karo
    fun backtest(q: Int = 8): String {
        val d = db.toList()
        if (d.size < 500) return "Backtest ke liye kam se kam 500 numbers chahiye"
        val split = d.size * 7 / 10
        val train = d.subList(0, split)
        var tested = 0; var found = 0; var firstOk = 0; var allOk = 0
        var i = split
        while (i + q + NEXT_N <= d.size) {
            val seq = d.subList(i, i + q)
            val actual = d.subList(i + q, i + q + NEXT_N)
            val m = findNext(train, seq)
            tested++
            if (m.isNotEmpty()) {
                found++
                val p = m[0].second
                if (p.isNotEmpty() && p[0] == actual[0]) firstOk++
                if (p == actual) allOk++
            }
            i += 5
        }
        return "Backtest ($tested test): match mila $found, agla 1 number sahi $firstOk, poore 60 sahi $allOk"
    }
}
