package com.example.collector

import android.content.Context
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Engine {
    const val NEXT_N = 60
    const val MIN_OVERLAP = 3

    private lateinit var ctx: Context
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    // db: purane se naye ke order mein. -1.0 = GAP ka nishaan
    @Volatile var db: MutableList<Double> = mutableListOf()
    @Volatile var live: MutableList<Double> = mutableListOf()
    @Volatile var lastNumbers: List<Double> = emptyList()
    @Volatile var lastResult: String = "Abhi tak koi screenshot nahi"
    @Volatile var toolText: String = ""
    @Volatile var lastOk: Long = 0L
    @Volatile var lastGap: Boolean = false

    // tracking (match chal raha hai ya nahi)
    @Volatile var tracking: Boolean = false
    @Volatile var cands: List<Int> = emptyList()   // db ke wo index jahan tak abhi match hai
    @Volatile var trackLen: Int = 0
    @Volatile var previewIdx: Int = 1
    @Volatile var onUpdate: (() -> Unit)? = null

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        val f = File(ctx.filesDir, "db.txt")
        if (f.exists()) {
            db = f.readText().split(",").filter { it.isNotBlank() }.map { it.trim().toDouble() }.toMutableList()
        }
    }

    // ---------- disha ki jaanch ----------
    // do screenshot ke beech list kis taraf khiski, us se pata chalta hai naya number kahan aa raha hai
    private var prevRaw: List<Double> = emptyList()
    @Volatile var dirLeft = 0     // naya number LEFT mein aaya
    @Volatile var dirRight = 0    // naya number RIGHT mein aaya

    private fun checkDirection(raw: List<Double>) {
        val p = prevRaw
        prevRaw = raw
        if (p.size < 5 || raw.size < 5 || p == raw) return
        val n = minOf(p.size, raw.size)
        for (s in 1..3) {
            val m = n - s
            if (m < 4) break
            val left = (0 until m).all { eq(raw[it + s], p[it]) }
            val right = (0 until m).all { eq(raw[it], p[it + s]) }
            if (left && !right) { dirLeft++; return }
            if (right && !left) { dirRight++; return }
        }
    }

    fun dirWarning(): String? {
        if (dirLeft + dirRight < 2) return null
        val newestLeft = dirLeft > dirRight
        return if (newestLeft != reverse)
            "DISHA GALAT: naya number ${if (newestLeft) "LEFT" else "RIGHT"} aa raha hai, REVERSE ${if (newestLeft) "tick" else "untick"} karo"
        else null
    }

    fun dirStatus(): String {
        if (dirLeft + dirRight < 2) return "Disha: ek-do naye round ke baad pata chalega"
        val newestLeft = dirLeft > dirRight
        val side = if (newestLeft) "LEFT" else "RIGHT"
        return if (dirWarning() == null) "Disha OK: naya number $side mein aa raha hai, REVERSE sahi hai"
        else "DISHA GALAT: naya number $side mein aa raha hai, REVERSE ${if (newestLeft) "tick" else "untick"} karo"
    }

    // ---------- settings ----------
    private fun prefs() = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var topPct: Int
        get() = prefs().getInt("top", 0)
        set(v) { prefs().edit().putInt("top", v).apply() }
    var bottomPct: Int
        get() = prefs().getInt("bottom", 100)
        set(v) { prefs().edit().putInt("bottom", v).apply() }
    var intervalSec: Int
        get() = prefs().getInt("interval_sec", 20)
        set(v) { prefs().edit().putInt("interval_sec", v.coerceAtLeast(5)).apply() }
    var reverse: Boolean
        get() = prefs().getBoolean("reverse", true)
        set(v) { prefs().edit().putBoolean("reverse", v).apply() }
    var singleRow: Boolean
        get() = prefs().getBoolean("single_row", true)
        set(v) { prefs().edit().putBoolean("single_row", v).apply() }
    var target: Int
        get() = prefs().getInt("target", 10000)
        set(v) { prefs().edit().putInt("target", v.coerceAtLeast(100)).apply() }
    var startLen: Int
        get() = prefs().getInt("start_len", 10)
        set(v) { prefs().edit().putInt("start_len", v.coerceAtLeast(5)).apply() }
    var tolHundredths: Int
        get() = prefs().getInt("tol", 1)
        set(v) { prefs().edit().putInt("tol", v.coerceAtLeast(0)).apply() }
    var wildcard: Int
        get() = prefs().getInt("wild", 100)
        set(v) { prefs().edit().putInt("wild", v.coerceAtLeast(10)).apply() }
    var overlayOn: Boolean
        get() = prefs().getBoolean("overlay_on", true)
        set(v) { prefs().edit().putBoolean("overlay_on", v).apply() }
    var predicted: Int
        get() = prefs().getInt("pred", 0)
        set(v) { prefs().edit().putInt("pred", v).apply() }
    var hits: Int
        get() = prefs().getInt("hits", 0)
        set(v) { prefs().edit().putInt("hits", v).apply() }

    val tol: Double get() = tolHundredths / 100.0
    val count: Int get() = db.count { it > 0 }
    val gaps: Int get() = db.count { it < 0 }
    fun mode() = if (count < target) "COLLECT" else "MATCH"

    private fun saveDb() = File(ctx.filesDir, "db.txt").writeText(db.joinToString(","))

    fun reset() {
        db = mutableListOf(); live = mutableListOf(); saveDb()
        resetTracking(); predicted = 0; hits = 0
        lastResult = "Data reset ho gaya"; lastNumbers = emptyList(); toolText = ""
        onUpdate?.invoke()
    }

    // do number "barabar" maane jayenge agar farq tolerance ke andar ho, ya dono bade (wildcard) hon
    fun eq(a: Double, b: Double): Boolean {
        if (a <= 0 || b <= 0) return false
        if (a >= wildcard && b >= wildcard) return true
        return Math.abs(a - b) <= tol + 1e-9
    }

    // ================= screenshot -> OCR =================
    private data class Item(val v: Double, val cx: Int, val cy: Int, val h: Int)
    private val strictRx = Regex("""^(\d+\.\d{2})\s*[xX\u00D7]$""")
    private val looseRx = Regex("""^(\d+\.\d{2})\s*[xX\u00D7]?$""")

    fun process(bmp: Bitmap) {
        val h = bmp.height
        val t = (h * topPct / 100).coerceIn(0, h - 2)
        val b = (h * bottomPct / 100).coerceIn(t + 1, h)
        val crop = Bitmap.createBitmap(bmp, 0, t, bmp.width, b - t)
        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { res ->
                val els = res.textBlocks.flatMap { it.lines }.flatMap { it.elements }
                fun pick(rx: Regex): List<Item> = els.mapNotNull { e ->
                    val box = e.boundingBox ?: return@mapNotNull null
                    val m = rx.find(e.text.trim()) ?: return@mapNotNull null
                    val v = m.groupValues[1].toDouble()
                    if (v < 1.0) null else Item(v, box.centerX(), box.centerY(), box.height())
                }
                var items = pick(strictRx)
                if (items.size < 5) items = pick(looseRx)
                if (items.size >= 3) {
                    val med = items.map { it.h }.sorted()[items.size / 2]
                    items = items.filter { it.h <= med * 1.8 }
                }
                readVia = "OCR"
                handle(order(items))
            }
            .addOnFailureListener { lastResult = "OCR error: ${it.message}" }
    }

    // ----- seedha screen ka text (Accessibility), bina screenshot/OCR -----
    class NodeText(val text: String, val cx: Int, val cy: Int, val h: Int)
    @Volatile var readVia: String = "-"

    fun processNodes(nodes: List<NodeText>): Boolean {
        var items = nodes.mapNotNull { n ->
            val m = strictRx.find(n.text.trim()) ?: return@mapNotNull null
            val v = m.groupValues[1].toDouble()
            if (v < 1.0) null else Item(v, n.cx, n.cy, n.h)
        }
        if (items.size < 5) return false
        val med = items.map { it.h }.sorted()[items.size / 2]
        items = items.filter { it.h <= med * 1.8 }
        if (items.size < 5) return false
        readVia = "TEXT"
        handle(order(items))
        return true
    }

    fun describeNodes(nodes: List<NodeText>): String {
        val match = nodes.filter { strictRx.containsMatchIn(it.text.trim()) }
        val sample = nodes.take(8).joinToString(" | ") { it.text.take(18) }
        val verdict = if (match.size >= 5) "TEXT mode chalega, OCR ki zaroorat nahi."
        else "Kam mile, screenshot (OCR) se padhna padega."
        return "Text test: ${nodes.size} text mile, ${match.size} multiplier jaise (x ke saath). $verdict\nNamune: $sample"
    }

    private fun order(items: List<Item>): List<Double> {
        if (items.isEmpty()) return emptyList()
        val med = items.map { it.h }.sorted()[items.size / 2]
        val rows = mutableListOf<MutableList<Item>>()
        for (x in items.sortedBy { it.cy }) {
            val last = rows.lastOrNull()
            if (last != null && x.cy - last.last().cy <= med * 0.6) last.add(x) else rows.add(mutableListOf(x))
        }
        val use = if (singleRow) rows.take(1) else rows
        return use.flatMap { r -> r.sortedBy { it.cx }.map { it.v } }
    }

    @Synchronized
    private fun handle(found: List<Double>) {
        checkDirection(found)
        val nums = if (reverse) found.reversed() else found
        lastNumbers = nums
        val stamp = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date())
        if (nums.size < 3) { lastResult = "[$stamp] Sirf ${nums.size} number mile, skip"; onUpdate?.invoke(); return }
        lastOk = System.currentTimeMillis()

        if (count < target) {
            val before = count
            db = merge(db, nums).toMutableList()
            saveDb()
            lastResult = "[$stamp] Collect: $count/$target (naye ${count - before}, padhe ${nums.size})" +
                if (lastGap) "  GAP lagaya" else ""
        } else {
            val old = live
            val merged = merge(old, nums)
            val added = merged.subList(old.size, merged.size)
            if (added.isEmpty()) return                      // koi naya round nahi
            live = (if (merged.size > 60) merged.takeLast(60) else merged).toMutableList()
            for (r in added) { if (r < 0) resetTracking() else step(r) }
            if (!tracking) search()
            val (a, b, c) = popupLines()
            lastResult = "[$stamp] $a | $b | $c"
        }
        onUpdate?.invoke()
    }

    // ================= merge =================
    private fun overlapOk(a: List<Double>, b: List<Double>, k: Int): Boolean {
        var bad = 0
        val allowed = if (k >= 5) 1 else 0     // OCR ki ek galti maaf
        for (i in 0 until k) {
            if (!eq(a[a.size - k + i], b[i])) { bad++; if (bad > allowed) return false }
        }
        return true
    }

    fun merge(base: List<Double>, new: List<Double>): List<Double> {
        lastGap = false
        if (base.isEmpty()) return new
        val need = minOf(MIN_OVERLAP, new.size)
        for (k in minOf(base.size, new.size) downTo need) {
            if (overlapOk(base, new, k)) return base + new.subList(k, new.size)
        }
        lastGap = true
        return base + listOf(-1.0) + new
    }

    // ================= match / tracking =================
    // ctx ke sabse lambe suffix wale match. return: (position, context length, agle numbers)
    fun bestMatches(data: List<Double>, ctxNums: List<Double>, minLen: Int = startLen, cap: Int = 20):
        List<Triple<Int, Int, List<Double>>> {
        if (ctxNums.size < minLen) return emptyList()
        val lastV = ctxNums.last()
        var best = 0
        val hits = ArrayList<Pair<Int, Int>>()
        for (e in 0 until data.size - 1) {
            if (!eq(data[e], lastV)) continue
            var len = 0
            while (len < ctxNums.size && e - len >= 0 && eq(data[e - len], ctxNums[ctxNums.size - 1 - len])) len++
            if (len >= minLen) {
                if (len > best) { best = len; hits.clear() }
                if (len == best) hits.add(e to len)
            }
        }
        return hits.take(cap).mapNotNull { (e, l) ->
            val nxt = data.subList(e + 1, minOf(e + 1 + NEXT_N, data.size)).takeWhile { it > 0 }
            if (nxt.isEmpty()) null else Triple(e, l, nxt)
        }
    }

    data class Vote(val value: Double, val agree: Int, val total: Int, val min: Double, val max: Double)

    // i round aage ka vote (kai jagah ke match mein se jo sabse zyada baar aaya)
    fun voteAt(i: Int): Vote? {
        val vals = ArrayList<Double>()
        for (c in cands) {
            val idx = c + i
            if (idx >= db.size) continue
            if (db.subList(c + 1, idx + 1).any { it <= 0 }) continue
            vals.add(db[idx])
        }
        if (vals.isEmpty()) return null
        val groups = vals.groupBy { if (it >= wildcard) -2.0 else Math.round(it * 100) / 100.0 }
        val top = groups.maxByOrNull { it.value.size }!!
        val v = if (top.key == -2.0) top.value.minOrNull()!! else top.key
        return Vote(v, top.value.size, vals.size, vals.minOrNull()!!, vals.maxOrNull()!!)
    }

    fun voteText(v: Vote): String {
        val base = if (v.value >= wildcard) "$wildcard+" else String.format(Locale.US, "%.2f", v.value)
        val lower = v.min < v.value - tol - 1e-9 && v.value < wildcard
        val higher = v.max > v.value + tol + 1e-9 && v.value < wildcard
        return base + (if (lower) "<" else "") + (if (higher) ">" else "")
    }

    private fun resetTracking() { tracking = false; cands = emptyList(); trackLen = 0; previewIdx = 1 }

    // naya asli round r aaya: pichhli prediction check karo, match jaari rakho ya roko
    private fun step(r: Double) {
        if (!tracking) return
        val v = voteAt(1)
        if (v != null) {
            predicted += 1
            if (eq(v.value, r)) hits += 1
        }
        val keep = cands.filter { it + 1 < db.size && eq(db[it + 1], r) }
        if (keep.isEmpty()) resetTracking()
        else { cands = keep.map { it + 1 }; trackLen += 1; previewIdx = 1 }
    }

    private fun search() {
        val c = live.takeLastWhile { it > 0 }
        val m = bestMatches(db, c)
        if (m.isNotEmpty()) {
            tracking = true
            cands = m.map { it.first }
            trackLen = m[0].second
            previewIdx = 1
        }
    }

    fun next() { previewIdx = (previewIdx + 1).coerceAtMost(NEXT_N); onUpdate?.invoke() }
    fun prev() { previewIdx = (previewIdx - 1).coerceAtLeast(1); onUpdate?.invoke() }

    private fun scoreText(): String {
        val p = predicted
        return if (p == 0) "Scoreboard: abhi koi prediction nahi"
        else "Sahi $hits/$p (${hits * 100 / p}%)"
    }

    // popup ki teen lines
    fun popupLines(): Triple<String, String, String> {
        val t = popupCore()
        val w = dirWarning()
        return if (w != null) Triple(w, t.second, t.third) else t
    }

    private fun popupCore(): Triple<String, String, String> {
        if (count < target) return Triple("Data jama ho raha hai", "$count/$target", "Gap: $gaps")
        if (!tracking) return Triple("Match ruka, dekh raha hu", "-", scoreText())
        val v = voteAt(previewIdx)
            ?: return Triple("Match hai par aage data nahi", "-", scoreText())
        return Triple(
            "MATCH: context $trackLen | ${cands.size} jagah",
            "R+$previewIdx: ${voteText(v)}   (${v.agree}/${v.total} ek jaisa)",
            scoreText()
        )
    }

    // ================= Repeat Check =================
    private fun repeatStats(list: List<Double>, len: Int): Pair<Int, Int> {
        val counts = HashMap<String, Int>()
        var windows = 0
        for (i in 0..(list.size - len)) {
            var ok = true
            for (j in 0 until len) if (list[i + j] <= 0) { ok = false; break }
            if (!ok) continue
            windows++
            val key = list.subList(i, i + len).joinToString(",")
            counts[key] = (counts[key] ?: 0) + 1
        }
        return windows to counts.values.filter { it >= 2 }.sum()
    }

    fun repeatCheck(): String {
        val d = db.toList()
        val pos = d.count { it > 0 }
        if (pos < 300) return "Repeat check ke liye kam se kam 300 numbers chahiye (abhi $pos)"
        val sh = d.toMutableList()
        val idx = sh.indices.filter { sh[it] > 0 }
        val vals = idx.map { sh[it] }.toMutableList()
        vals.shuffle(java.util.Random(42))
        idx.forEachIndexed { k, i -> sh[i] = vals[k] }
        val sb = StringBuilder("Repeat check ($pos numbers, $gaps gap):\n")
        for (len in listOf(6, 10, 15)) {
            val (w, r) = repeatStats(d, len)
            val (w2, r2) = repeatStats(sh, len)
            sb.append("$len numbers ka sequence: asli $r/$w dobara aaye | shuffle par $r2/$w2\n")
        }
        sb.append("Saboot tabhi hai jab asli ka figure shuffle wale se bahut zyada ho.")
        return sb.toString()
    }

    // ================= Backtest =================
    fun backtest(): String {
        val d = db.toList()
        if (d.count { it > 0 } < 500) return "Backtest ke liye kam se kam 500 numbers chahiye"
        val split = d.size * 7 / 10
        val train = d.subList(0, split)
        var tested = 0; var matched = 0; var hit1 = 0; var hit3 = 0
        var t = split + 30
        while (t + 10 <= d.size) {
            val actual = d.subList(t, t + 10)
            if (actual.any { it < 0 }) { t += 5; continue }
            val c = d.subList(t - 30, t).takeLastWhile { it > 0 }
            tested++
            val m = bestMatches(train, c)
            if (m.isNotEmpty()) {
                matched++
                val p = m[0].third
                if (eq(p[0], actual[0])) hit1++
                if (p.size >= 3 && (0 until 3).all { eq(p[it], actual[it]) }) hit3++
            }
            t += 5
        }
        return "Backtest: $tested test | match mila $matched | agla 1 sahi $hit1 | agle 3 sahi $hit3"
    }

    // ================= Backup / Import =================
    fun exportText(): String = "COLLECTOR_BACKUP\n" + db.joinToString(",")

    fun importText(text: String, newestFirst: Boolean): String {
        val raw = Regex("""-?\d+(?:\.\d+)?""").findAll(text).map { it.value.toDouble() }
            .filter { it > 0 || it == -1.0 }.toList()
        if (raw.isEmpty()) return "Import: file mein koi number nahi mila"
        val isBackup = text.trimStart().startsWith("COLLECTOR_BACKUP")
        val nums = if (!isBackup && newestFirst) raw.reversed() else raw
        db = (if (db.isEmpty()) nums else db + listOf(-1.0) + nums).toMutableList()
        saveDb()
        return "Import ho gaya: ${nums.count { it > 0 }} numbers. Ab data: $count"
    }
}
