package com.example.collector

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.WindowManager
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    companion object {
        const val REQ_EXPORT = 11
        const val REQ_IMPORT = 12
    }

    private lateinit var status: TextView
    private var importNewestFirst = false
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 2000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Engine.init(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        status = TextView(this).apply { textSize = 14f }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun field(hint: String, v: Int) = EditText(this).apply {
            this.hint = hint; setText(v.toString()); inputType = InputType.TYPE_CLASS_NUMBER
        }

        val top = field("Upar se kitna % chhodna hai (0-100)", Engine.topPct)
        val bottom = field("Kahan tak padhna hai % (0-100)", Engine.bottomPct)
        val secs = field("Screenshot interval (second, jaise 20)", Engine.intervalSec)
        val target = field("Kitne round jama karne hain (10000)", Engine.target)
        val startLen = field("Predict shuru: kitne round match hon (10)", Engine.startLen)
        val tol = field("Tolerance (0.01 ke liye 1, exact ke liye 0)", Engine.tolHundredths)
        val wild = field("Is x ke upar ke numbers ko barabar maano (100)", Engine.wildcard)
        val rev = CheckBox(this).apply { text = "Naya number pehle/left hai (REVERSE)"; isChecked = Engine.reverse }
        val single = CheckBox(this).apply {
            text = "Sirf upar ki ek patti padho (main screen). History popup ke liye band karo"
            isChecked = Engine.singleRow
        }

        root.addView(status)
        for (v in listOf(top, bottom, secs, target, startLen, tol, wild)) root.addView(v)
        root.addView(rev); root.addView(single)
        root.addView(btn("Settings save karo") {
            Engine.topPct = top.text.toString().toIntOrNull() ?: 0
            Engine.bottomPct = bottom.text.toString().toIntOrNull() ?: 100
            Engine.intervalSec = secs.text.toString().toIntOrNull() ?: 20
            Engine.target = target.text.toString().toIntOrNull() ?: 10000
            Engine.startLen = startLen.text.toString().toIntOrNull() ?: 10
            Engine.tolHundredths = tol.text.toString().toIntOrNull() ?: 1
            Engine.wildcard = wild.text.toString().toIntOrNull() ?: 100
            Engine.reverse = rev.isChecked
            Engine.singleRow = single.isChecked
            Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("1. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2. Battery optimization band karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("Popup dikhao / chhupao") {
            ShotService.instance?.toggleOverlay()
                ?: Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("Test: 5 sec baad screenshot (game par jao)") {
            ShotService.instance?.captureIn(5000)
                ?: Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("Screen text test (5 sec, game par jao)") {
            ShotService.instance?.textTestIn(5000)
                ?: Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("Repeat Check (data mein repeat hai?)") {
            Engine.toolText = "Repeat check chal raha hai..."
            thread { Engine.toolText = Engine.repeatCheck() }
        })
        root.addView(btn("Backtest chalao") {
            Engine.toolText = "Backtest chal raha hai..."
            thread { Engine.toolText = Engine.backtest() }
        })
        root.addView(btn("Backup save karo (file mein)") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"
                putExtra(Intent.EXTRA_TITLE, "collector_backup.txt")
            }, REQ_EXPORT)
        })
        root.addView(btn("Import (purana data file se)") {
            AlertDialog.Builder(this).setTitle("File mein numbers kis order mein hain?")
                .setItems(arrayOf("Naya number PEHLE (screen jaisa)", "Naya number AAKHIR mein (purana se naya)")) { _, which ->
                    importNewestFirst = (which == 0)
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    }, REQ_IMPORT)
                }.show()
        })
        root.addView(btn("Scoreboard zero karo") { Engine.predicted = 0; Engine.hits = 0 })
        root.addView(btn("Data reset") {
            AlertDialog.Builder(this).setMessage("Saara jama data hat jayega. Pakka?")
                .setPositiveButton("Haan") { _, _ -> Engine.reset() }
                .setNegativeButton("Nahi", null).show()
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_EXPORT -> thread {
                Engine.toolText = try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(Engine.exportText().toByteArray()) }
                    "Backup save ho gaya"
                } catch (e: Exception) { "Backup error: ${e.message}" }
            }
            REQ_IMPORT -> thread {
                Engine.toolText = try {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    Engine.importText(text, importNewestFirst)
                } catch (e: Exception) { "Import error: ${e.message}" }
            }
        }
    }

    private fun refresh() {
        val on = ShotService.instance != null
        val ago = if (Engine.lastOk == 0L) -1L else (System.currentTimeMillis() - Engine.lastOk) / 1000
        val warn = if (on && ago > maxOf(120, Engine.intervalSec * 4L))
            "\n!! $ago sec se koi sahi screenshot nahi mila. Game screen par hai? Screen on hai?" else ""
        val svc = if (on) "ON" else "OFF (Accessibility on karo)"
        val lastOkText = if (ago < 0) "-" else "$ago sec pehle"
        status.text = "Service: $svc  |  Last sahi screenshot: $lastOkText$warn\n" +
            "Mode: ${Engine.mode()}  |  Data: ${Engine.count}/${Engine.target}  |  Gap: ${Engine.gaps}\n" +
            "Padhne ka tarika: ${Engine.readVia}  |  ${Engine.dirStatus()}\n\n" +
            "Last numbers: ${Engine.lastNumbers}\n\n${Engine.lastResult}\n\n${Engine.toolText}\n"
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
