package com.example.collector

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.WindowManager
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 2000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Engine.init(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        status = TextView(this).apply { textSize = 14f }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun field(hint: String, v: Int) = EditText(this).apply {
            this.hint = hint; setText(v.toString()); inputType = InputType.TYPE_CLASS_NUMBER
        }

        val top = field("Upar se kitna % chhodna hai (0-100)", Engine.topPct)
        val bottom = field("Kahan tak padhna hai % (0-100)", Engine.bottomPct)
        val mins = field("Screenshot interval (minute)", Engine.intervalMin)
        val rev = CheckBox(this).apply { text = "Naya number pehle/upar hai (REVERSE)"; isChecked = Engine.reverse }

        root.addView(status)
        root.addView(top); root.addView(bottom); root.addView(mins); root.addView(rev)
        root.addView(btn("Settings save karo") {
            Engine.topPct = top.text.toString().toIntOrNull() ?: 0
            Engine.bottomPct = bottom.text.toString().toIntOrNull() ?: 100
            Engine.intervalMin = mins.text.toString().toIntOrNull() ?: 60
            Engine.reverse = rev.isChecked
            Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("1. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2. Battery optimization band karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("Test: 5 sec baad screenshot (doosre app par jao)") {
            ShotService.instance?.captureIn(5000)
                ?: Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("Backtest chalao") {
            Engine.backtestText = "Backtest chal raha hai..."
            thread { Engine.backtestText = Engine.backtest() }
        })
        root.addView(btn("Data reset") {
            AlertDialog.Builder(this).setMessage("Saara jama data hat jayega. Pakka?")
                .setPositiveButton("Haan") { _, _ -> Engine.reset() }
                .setNegativeButton("Nahi", null).show()
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refresh() {
        val on = if (ShotService.instance != null) "ON" else "OFF (Accessibility on karo)"
        status.text = "Service: $on\nMode: ${Engine.mode()}  |  Data: ${Engine.db.size}/${Engine.TARGET}\n\n" +
            "Last numbers: ${Engine.lastNumbers}\n\n${Engine.lastResult}\n\n${Engine.backtestText}\n"
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
