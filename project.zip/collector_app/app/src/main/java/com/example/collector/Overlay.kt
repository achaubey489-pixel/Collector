package com.example.collector

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// Game ke upar chhota popup (Accessibility overlay, alag permission nahi chahiye)
class Overlay(private val svc: AccessibilityService) {
    private val wm = svc.getSystemService(WindowManager::class.java)
    private var root: LinearLayout? = null
    private var l1: TextView? = null
    private var l2: TextView? = null
    private var l3: TextView? = null
    private var lp: WindowManager.LayoutParams? = null

    fun isShown() = root != null

    fun show() {
        if (root != null) return
        val d = svc.resources.displayMetrics.density
        val r = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            setBackgroundColor(Color.parseColor("#E6101820"))
            minimumWidth = (260 * d).toInt()
        }
        val a = TextView(svc).apply { setTextColor(Color.parseColor("#B0BEC5")); textSize = 12f }
        val b = TextView(svc).apply { setTextColor(Color.WHITE); textSize = 22f; setTypeface(null, Typeface.BOLD) }
        val c = TextView(svc).apply { setTextColor(Color.parseColor("#80CBC4")); textSize = 12f }
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(svc).apply {
            text = t; textSize = 12f
            setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(btn("<") { Engine.prev() })
        row.addView(btn("Next >") { Engine.next() })
        row.addView(btn("X") { hide(); Engine.overlayOn = false })
        r.addView(a); r.addView(b); r.addView(c); r.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (120 * d).toInt() }

        // upar ke text ko pakad kar popup khiskaya ja sakta hai
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        val drag = View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - downX).toInt()
                    params.y = startY - (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(r, params) } catch (_: Exception) {}
                }
            }
            true
        }
        a.setOnTouchListener(drag); b.setOnTouchListener(drag); c.setOnTouchListener(drag)

        try {
            wm.addView(r, params)
            root = r; l1 = a; l2 = b; l3 = c; lp = params
            refresh()
        } catch (e: Exception) {
            Engine.toolText = "Popup nahi khula: ${e.message}"
        }
    }

    fun hide() {
        val r = root ?: return
        try { wm.removeView(r) } catch (_: Exception) {}
        root = null
    }

    // screenshot ke waqt popup chhupao, taaki OCR uske text ko na padhe
    fun setCapturing(on: Boolean) {
        root?.visibility = if (on) View.INVISIBLE else View.VISIBLE
    }

    fun refresh() {
        val r = root ?: return
        r.post {
            val (x, y, z) = Engine.popupLines()
            l1?.text = x; l2?.text = y; l3?.text = z
        }
    }
}
